/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbos01;

/**
 *
 * @author diles
 */
public class Book {
    String author;
    String title;
    String isbnNumber;
    
    public Book(String author, String title, String isbnNumber){
        this.author = author;
        this.title = title;
        this.isbnNumber = isbnNumber;
    }
}
