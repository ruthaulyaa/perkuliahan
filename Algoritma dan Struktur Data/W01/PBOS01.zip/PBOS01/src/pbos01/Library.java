/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbos01;

import java.util.ArrayList;
/**
 *
 * @author diles
 */
public class Library implements LibraryBookInterface{ 
    
    ArrayList<LibraryBook> allLibraryBooks = new ArrayList<LibraryBook>();
    
    //libraryBooks.add(books);
    
                
    @Override
    public void addLibraryBook(LibraryBook books){
        allLibraryBooks.add(books);
    }
    
    @Override
    public void checkOut(String isbnNumber, String dueDate, String newHolder){
        //libraryBook.add(0, );
        //libraryBook.dueDate = dueDate;
        //libraryBook.holder = holder;
        
        for (LibraryBook libraryBook : allLibraryBooks) {
            if (libraryBook.getISBNNumber().equals(isbnNumber) && libraryBook.getDueDate().equals(dueDate) && libraryBook.getHolder().equals(newHolder)){
                System.out.println("Book Title: " + libraryBook.getTitle());
                System.out.println("Book Author: " + libraryBook.getAuthor());
            }
        }
    }
    
    @Override
    public String checkCurrentHolder(String isbnNumber){
        String currentHolder = null;
        
        for (LibraryBook libraryBook : allLibraryBooks) {
            if (libraryBook.getISBNNumber().equals(isbnNumber)){
                    currentHolder = libraryBook.getHolder();
            }
        }
        
        return currentHolder;
    }
    
    public void viewData(){
      /*for (LibraryBook libraryBook : allLibraryBook) {
        System.out.println("test: " + libraryBook.getAuthor());
    }*/
      
        for(int i=0; i < allLibraryBooks.size(); i++)
            System.out.println("test: " + allLibraryBooks.get(i).author);
    }
}

