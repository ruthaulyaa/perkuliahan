/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbos01;

import java.util.ArrayList;

/**
 *
 * @author diles
 */
public class LibraryBook extends Book{
    String dueDate;
    String holder;
    boolean checkOut;

    public LibraryBook(String author, String title, String isbnNumber, String dueDate, String holder) {
        super(author, title, isbnNumber);
        
        this.author = author;
        this.title = title;
        this.isbnNumber = isbnNumber;
        this.dueDate = dueDate;
        this.holder = holder;
    }
    
    public String getAuthor(){
        return this.author;
    }
    
    public String getTitle(){
        return this.title;
    }
    
    public String getISBNNumber(){
        return this.isbnNumber;
    }
    
    public String getDueDate(){
        return this.dueDate;
    }
    
    public String getHolder(){
        return this.holder;
    }
}
