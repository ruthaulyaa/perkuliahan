/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbos01;

/**
 *
 * @author diles
 */
public class PBOS01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       LibraryBook libraryBook1 = new LibraryBook("A02", "T002", "099", "29-08-2020", "Jack");
        
       Library library = new Library();
        
       library.addLibraryBook(libraryBook1);
        
       LibraryBook libraryBook2 = new LibraryBook("A03", "T003", "089", "29-08-2020", "Ann");
       
       library.addLibraryBook(libraryBook2);
        
       library.viewData();
       
       library.checkOut("089", "29-08-2020", "Ann");
       
       System.out.println("Current Ho;der: " + library.checkCurrentHolder("089"));
    }
    
}
