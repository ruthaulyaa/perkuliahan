# PABWE ITDEL - 11S18005

### 05-09-2022
1. Membuat tampilan awal, berisikan daftar link ke hasil praktikum mingguan.
