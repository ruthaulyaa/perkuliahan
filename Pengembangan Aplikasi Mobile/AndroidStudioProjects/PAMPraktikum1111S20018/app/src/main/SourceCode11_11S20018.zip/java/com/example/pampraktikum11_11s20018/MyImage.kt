package com.example.pampraktikum11_11s20018

class MyImage (
    val id : String = "",
    val label : String = "",
    val url : String = "",
    val imageName : String = ""
){
    constructor() : this("","","","")
}