//package com.example.pampraktikum11_11s20018
//
//import android.content.Intent
//import android.content.pm.PackageManager
//import android.net.Uri
//import androidx.appcompat.app.AppCompatActivity
//import android.os.Bundle
//import android.view.Menu
//import android.view.MenuItem
//import android.view.View
//import android.widget.Toast
//import androidx.activity.result.ActivityResultCallback
//import androidx.activity.result.ActivityResultLauncher
//import androidx.activity.result.contract.ActivityResultContracts
//import androidx.core.app.ActivityCompat
//import androidx.core.content.ContextCompat
//import androidx.recyclerview.widget.LinearLayoutManager
//import com.example.pampraktikum11_11s20018.databinding.ActivityMainBinding
//import com.google.firebase.auth.FirebaseAuth
//import com.google.firebase.database.*
//import com.google.firebase.storage.FirebaseStorage
//import com.google.firebase.storage.StorageReference
//import com.squareup.picasso.Picasso
//import java.util.*
//
//class MainActivity : AppCompatActivity() {
//
//    lateinit var mainBinding: ActivityMainBinding
//
//    lateinit var activityResultLauncher: ActivityResultLauncher<Intent>
//
//    var imageUri : Uri? = null
//
//    val db : FirebaseDatabase = FirebaseDatabase.getInstance()
//    val dbRef : DatabaseReference = db.reference.child("images")
//
//    val firebaseStorage : FirebaseStorage = FirebaseStorage.getInstance()
//    val storageRef : StorageReference = firebaseStorage.reference
//
//    val myImageList = ArrayList<MyImage>()
//    lateinit var myImageAdapter: MyImageAdapter
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        mainBinding = ActivityMainBinding.inflate(layoutInflater)
//        val view = mainBinding.root
//        setContentView(view)
//
//        registerActivityForResult()
//
//        mainBinding.ivData.setOnClickListener{
//            chooseImage()
//        }
//
//        mainBinding.btnSave.setOnClickListener{
//            uploadPhoto()
//        }
//
//        retrieveDataFromDatabase()
//
//    }
//
//    fun chooseImage(){
//        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
//            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 1)
//        }else{
//            val intent = Intent()
//            intent.type = "image/*"
//            intent.action = Intent.ACTION_GET_CONTENT
//            activityResultLauncher.launch(intent)
//        }
//    }
//
//    override fun onRequestPermissionsResult(
//        requestCode: Int,
//        permissions: Array<out String>,
//        grantResults: IntArray
//    ) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED){
//            val intent = Intent()
//            intent.type = "image/*"
//            intent.action = Intent.ACTION_GET_CONTENT
//            activityResultLauncher.launch(intent)
//        }
//    }
//
//    fun registerActivityForResult(){
//        activityResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult(), ActivityResultCallback { result ->
//            val resultCode = result.resultCode
//            val imageData = result.data
//
//            if(resultCode == RESULT_OK && imageData != null){
//                imageUri = imageData.data
//                imageUri?.let {
//                    Picasso.get().load(it).into(mainBinding.ivData)
//                }
//            }
//        })
//    }
//
//    fun uploadPhoto(){
//        mainBinding.btnSave.isClickable = false
//        mainBinding.pbUpload.visibility = View.VISIBLE
//        //UUID
//        val imageName = UUID.randomUUID().toString()
//        val imageRef = storageRef.child("images").child(imageName)
//        imageUri?.let { uri ->
//            imageRef.putFile(uri).addOnSuccessListener {
//                Toast.makeText(
//                    applicationContext,
//                    "Image Uploaded",
//                    Toast.LENGTH_SHORT
//                ).show()
//
//                val myUploadImageRef = storageRef.child("images").child(imageName)
//                myUploadImageRef.downloadUrl.addOnSuccessListener { url ->
//                    val imageUrl = url.toString()
//                    addImageToDatabase(imageUrl, imageName)
//                }
//            }.addOnFailureListener{
//                Toast.makeText(
//                    applicationContext,
//                    it.localizedMessage,
//                    Toast.LENGTH_SHORT
//                ).show()
//
//                mainBinding.btnSave.isClickable = true
//                mainBinding.pbUpload.visibility = View.GONE
//            }
//        }
//    }
//
//    fun addImageToDatabase(url : String, imageName : String){
//        val label : String = mainBinding.etLabel.text.toString()
//        val id : String = dbRef.push().key.toString()
//
//        val myImage = MyImage(id, label, url, imageName)
//
//        dbRef.child(id).setValue(myImage).addOnCompleteListener { task ->
//            if (task.isSuccessful){
//                Toast.makeText(
//                    applicationContext,
//                    "The new image has been added to the database",
//                    Toast.LENGTH_SHORT
//                ).show()
//            }else{
//                Toast.makeText(
//                    applicationContext,
//                    task.exception.toString(),
//                    Toast.LENGTH_SHORT
//                ).show()
//            }
//
//            mainBinding.btnSave.isClickable = true
//            mainBinding.pbUpload.visibility = View.GONE
//        }
//
//    }
//
//    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
//        menuInflater.inflate(R.menu.menu_home, menu)
//        return true
//    }
//
//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        if(item.itemId == R.id.miLogout){
//            FirebaseAuth.getInstance().signOut()
//            val intent = Intent(this@MainActivity, LoginActivity::class.java)
//            startActivity(intent)
//            finish()
//        }
//        return super.onOptionsItemSelected(item)
//    }
//
//    fun retrieveDataFromDatabase(){
//        dbRef.addValueEventListener(object : ValueEventListener{
//            override fun onDataChange(snapshot: DataSnapshot) {
//                myImageList.clear()
//
//                for(currentUser in snapshot.children){
//                    val myImage = currentUser.getValue(MyImage::class.java)
//                    if(myImage != null){
//                        myImageList.add(myImage)
//                    }
//                }
//
//                myImageAdapter = MyImageAdapter(this@MainActivity, myImageList)
//                mainBinding.rvImages.layoutManager = LinearLayoutManager(this@MainActivity)
//                mainBinding.rvImages.adapter = myImageAdapter
//            }
//
//            override fun onCancelled(error: DatabaseError) {
//                TODO("Not yet implemented")
//            }
//        })
//    }
//}
