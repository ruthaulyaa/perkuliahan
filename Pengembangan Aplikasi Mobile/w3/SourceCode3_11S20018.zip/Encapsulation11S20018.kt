package com.example.pampraktikum3_11s20018

fun main(args: Array<String>) {
//    var subject = Subject11S20018("PAM", 4)
    var subject = Subject11S20018("Pemograman Berbasis Mobile", 6)
//    subject.name = "Pemrograman Berbasis Mobile"
//    subject.sks = 6
    println("Matakuliah ${subject.name} dengan jumlah SKS ${subject.sks}")
}