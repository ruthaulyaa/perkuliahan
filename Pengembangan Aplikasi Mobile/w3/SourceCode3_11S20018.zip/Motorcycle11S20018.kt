package com.example.pampraktikum3_11s20018

class Motorcycle11S20018: Vehicle11S20018() {
}