package com.example.pampraktikum3_11s20018

class Atlantis11S20018 (override var name: String, override var temperature: String) : Place11S20018(), Environment11S20018 {

    override fun location(): String {
        return "Samudra Atlantik"
    }

}