package com.example.pampraktikum3_11s20018

interface Environment11S20018 {

    abstract fun location():String
    abstract var temperature:String

}