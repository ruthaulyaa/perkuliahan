package com.example.pampraktikum3_11s20018

abstract class Planet11S20018 {

    abstract var name:String
    abstract fun satellite()

}