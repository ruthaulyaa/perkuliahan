package com.example.pampraktikum3_11s20018

open class Card11S20018 {

    open fun shape(){
        println("Persegi panjang")
    }

}