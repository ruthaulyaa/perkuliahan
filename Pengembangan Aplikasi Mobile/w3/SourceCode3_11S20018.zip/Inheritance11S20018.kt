package com.example.pampraktikum3_11s20018

fun main(args: Array<String>) {
    var motorcycle = Motorcycle11S20018()
    motorcycle.type = "Motorcycle"
    motorcycle.model = "Yamaha"
    motorcycle.maxSpeed = 180
    motorcycle.show()
}