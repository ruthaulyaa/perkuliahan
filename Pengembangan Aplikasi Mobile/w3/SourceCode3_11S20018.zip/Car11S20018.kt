package com.example.pampraktikum3_11s20018

class Car11S20018 {
    var name: String? = null
    var model: Int? = null
}