package com.example.pampraktikum3_11s20018

class CardChild11S20018: Card11S20018() {

    fun originalShape() {
        super.shape()
    }

    override fun shape() {
        println("Lingkaran")
    }

}