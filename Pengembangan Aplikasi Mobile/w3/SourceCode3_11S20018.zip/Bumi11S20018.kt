package com.example.pampraktikum3_11s20018

class Bumi11S20018(override var name: String): Planet11S20018() {
    override fun satellite() {
        println("Bulan")
    }
}