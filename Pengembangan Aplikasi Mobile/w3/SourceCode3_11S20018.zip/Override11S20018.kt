package com.example.pampraktikum3_11s20018

fun main(args: Array<String>) {
    var card = CardChild11S20018()
    card.originalShape()
    card.shape()
}