package com.example.pampraktikum3_11s20018

open class Vehicle11S20018 {
    var type:String? = null
    var model:String? = null
    var maxSpeed:Int? = null

    fun show(){
        println("Type: ${type}")
        println("Model: ${model}")
        println("Max Speed: ${maxSpeed}")
    }
}