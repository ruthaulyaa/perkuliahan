package com.example.pampraktikum3_11s20018

class Subject11S20018 {

    var name:String? = null
    var sks:Int? = null
        private set

    constructor(name:String, sks:Int){
        this.name = name
        this.sks = sks
    }

}