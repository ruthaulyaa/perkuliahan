package com.example.pampraktikum3_11s20018

fun main(args: Array<String>) {
    var atlantis = Atlantis11S20018("Atlantis", "Dingin")
    println("Lokasi ${atlantis.name} terletak di ${atlantis.location()} memiliki suhu yang ${atlantis.temperature}")
}