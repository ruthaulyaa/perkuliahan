package com.example.pampraktikum1_11s20018

fun main(args: Array<String>){

//    var a = 5;
//    var b = 10;
//    var c = a+b;
//
//    println(c)

//    var age = 20; //valid
//    var _age = 20; //valid
//    var a ge = 512; //invalid
//    var 1age = 1; //invalid
//
    var age = 10; //ubah ke val
    age = 20;
    print(age)

}