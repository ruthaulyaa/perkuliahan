package com.example.pampraktikum1_11s20018

fun main(args: Array<String>) {

    var a: Double = 256.7
    var b: Int = a.toInt()
    var c: Byte = b.toByte()

    println(a)
    println(b)
    println(c)

}