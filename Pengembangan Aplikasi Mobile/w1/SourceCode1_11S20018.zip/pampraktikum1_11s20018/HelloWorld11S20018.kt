package com.example.pampraktikum1_11s20018

fun main(args: Array<String>){
    print("Hello World")
}