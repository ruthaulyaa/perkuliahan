package com.example.pampraktikum1_11s20018

fun main(args: Array<String>){

    var a:Boolean = true
    var b:Char = 'R'
    var c:Byte = 12
    var d:Short = 125
    var e:Int = 1000
    var f:Long = 2000L
    var g:Float = 3.3F
    var h: Double = 4.4

    println(a)
    println(b)
    println(c)
    println(d)
    println(e)
    println(f)
    println(g)
    println(h)
}