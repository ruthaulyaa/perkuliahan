package com.example.pampraktikum2_11s20018

fun main(args: Array<String>){
    var i = 0
    do{
        println(i)
    }while (i > 0)
}