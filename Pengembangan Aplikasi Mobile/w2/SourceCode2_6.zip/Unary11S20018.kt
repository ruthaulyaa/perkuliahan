package com.example.pampraktikum2_11s20018

fun main(args: Array<String>){

    var num1: Int = 10;
    var num2: Int = 20;

    println("+num1 ${+num1}")
    println("-num1 ${-num2}")
    println("!num ${!(num1 == num2)}")

    println()
    println("++num1 ${++num1}")
    println("--num1 ${--num1}")

    println()
    println("num2++ ${num2++}")
    println("num2-- ${num2--}")
}