package com.example.pampraktikum2_11s20018

fun main(args: Array<String>){

    var a: Int = 3
    var b: Int = 6

    println("a == b: ${a == b}")
    println("a != b: ${a != b}")
    println("a > b: ${a > b}")
    println("a < b: ${a < b}")
    println("a >= b: ${a >= b}")
    println("a <= b: ${a <= b}")

}