package com.example.pampraktikum2_11s20018

fun main(args: Array<String>){
    var rentangKarakter = 'a'.rangeTo('j')
    var karakter = 'k' in rentangKarakter
    println(rentangKarakter)
    println("k terdapat di rentangKarakter: ${karakter}")
}