package com.example.pampraktikum2_11s20018

fun main(args: Array<String>){
//    for(number in 1 .. 10){
//        println(number)
//    }

//    var arr = arrayListOf<Int>(2, 4, 6, 8, 10, 12, 14, 16, 18, 20)
//    var sum: Int = 0
//    for (number in arr){
//        sum += number
//    }
//    println(sum)

//    sum = 0
//    for(number in 0 .. (arr.size-1)){
//        sum += arr[number]
//    }
//    println(sum)

//    sum = 0
//    for(number in arr.indices){
//        sum =+ arr[number]
//    }
//    println(sum)

    var myData = arrayListOf<Int>(2, 4, 6, 8, 10, 12, 14, 16, 18, 20)
    myData.forEach{println(it)}

}