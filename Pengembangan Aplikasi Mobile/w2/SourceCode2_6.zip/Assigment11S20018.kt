package com.example.pampraktikum2_11s20018

fun main(args: Array<String>){
    var x:Int = 10;
    println("Nilai x = ${x}")
    x = 5;
    println("Nilai x = ${x}")
//    x += 20
    x = x + 20;
    println("Nilai x = ${x}")
//    x -= 10
    x = x - 10;
    println("Nilai x = ${x}")
//    x *= 10
    x = x * 10;
    println("Nilai x = ${x}")
//    x /= 3
    x = x / 3;
    println("Nilai x = ${x}")
//    x %= 2
    x = x  % 2;
    println("Nilai x = ${x}")
}